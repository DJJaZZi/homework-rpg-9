package com.narxoz.rpg.artifact;

public class WeightCalculator implements ArtifactVisitor {
    private int totalWeight = 0;

    public int getTotalWeight() { return totalWeight; }

    @Override
    public void visit(Weapon weapon) { totalWeight += weapon.getWeight(); }

    @Override
    public void visit(Potion potion) { totalWeight += potion.getWeight(); }

    @Override
    public void visit(Scroll scroll) { totalWeight += scroll.getWeight(); }

    @Override
    public void visit(Ring ring) { totalWeight += ring.getWeight(); }

    @Override
    public void visit(Armor armor) { totalWeight += armor.getWeight(); }
}